rm *.txt
rm submitAllJobs.dag.*
rm -rf log
rm -rf error
rm -rf output
rm -rf dag
