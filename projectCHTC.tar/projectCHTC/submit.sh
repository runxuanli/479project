#!/bin/bash

condor_submit_dag submitAllJobs.dag 
